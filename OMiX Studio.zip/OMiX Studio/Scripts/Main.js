var NoBeat
var Abeat
var Bbeat
var Cbeat
var Dbeat
var Ebeat
var Fbeat
var Gbeat
var Hbeat
var Ibeat
var Jbeat
var Kbeat
var Lbeat
var Mbeat
var Nbeat

var ran1 = ["Scripts/Clap.mp3","Scripts/Paper.mp3","Scripts/Metal.mp3","Scripts/Crunch.mp3","Scripts/Swoosh.mp3","Scripts/Glass.mp3"]
var ran2 = ["Scripts/Clap.mp3","Scripts/Paper.mp3","Scripts/Metal.mp3","Scripts/Crunch.mp3","Scripts/Swoosh.mp3","Scripts/Glass.mp3"]
var ran3 = ["Scripts/Clap.mp3","Scripts/Paper.mp3","Scripts/Metal.mp3","Scripts/Crunch.mp3","Scripts/Swoosh.mp3","Scripts/Glass.mp3"]
var ran4 = ["Scripts/Clap.mp3","Scripts/Paper.mp3","Scripts/Metal.mp3","Scripts/Crunch.mp3","Scripts/Swoosh.mp3","Scripts/Glass.mp3"]
var ran5 = ["Scripts/Clap.mp3","Scripts/Paper.mp3","Scripts/Metal.mp3","Scripts/Crunch.mp3","Scripts/Swoosh.mp3","Scripts/Glass.mp3"]
var ran6 = ["Scripts/Clap.mp3","Scripts/Paper.mp3","Scripts/Metal.mp3","Scripts/Crunch.mp3","Scripts/Swoosh.mp3","Scripts/Glass.mp3"]
var ran7 = ["Scripts/Clap.mp3","Scripts/Paper.mp3","Scripts/Metal.mp3","Scripts/Crunch.mp3","Scripts/Swoosh.mp3","Scripts/Glass.mp3"]
var ran8 = ["Scripts/Clap.mp3","Scripts/Paper.mp3","Scripts/Metal.mp3","Scripts/Crunch.mp3","Scripts/Swoosh.mp3","Scripts/Glass.mp3"]
var ran9 = ["Scripts/Clap.mp3","Scripts/Paper.mp3","Scripts/Metal.mp3","Scripts/Crunch.mp3","Scripts/Swoosh.mp3","Scripts/Glass.mp3"]
var ran10 = ["Scripts/Clap.mp3","Scripts/Paper.mp3","Scripts/Metal.mp3","Scripts/Crunch.mp3","Scripts/Swoosh.mp3","Scripts/Glass.mp3"]
var ran11 = ["Scripts/Clap.mp3","Scripts/Paper.mp3","Scripts/Metal.mp3","Scripts/Crunch.mp3","Scripts/Swoosh.mp3","Scripts/Glass.mp3"]
var ran12 = ["Scripts/Clap.mp3","Scripts/Paper.mp3","Scripts/Metal.mp3","Scripts/Crunch.mp3","Scripts/Swoosh.mp3","Scripts/Glass.mp3"]
var ran13 = ["Scripts/Clap.mp3","Scripts/Paper.mp3","Scripts/Metal.mp3","Scripts/Crunch.mp3","Scripts/Swoosh.mp3","Scripts/Glass.mp3"]
var ran14 = ["Scripts/Clap.mp3","Scripts/Paper.mp3","Scripts/Metal.mp3","Scripts/Crunch.mp3","Scripts/Swoosh.mp3","Scripts/Glass.mp3"]
  
function ranbeat() {

    Abeat = ran1[Math.floor(Math.random() * ran1.length)]
    Bbeat = ran2[Math.floor(Math.random() * ran2.length)]
    Cbeat = ran2[Math.floor(Math.random() * ran2.length)]
    Dbeat = ran1[Math.floor(Math.random() * ran1.length)]
    Ebeat = ran2[Math.floor(Math.random() * ran2.length)]
    Fbeat = ran2[Math.floor(Math.random() * ran2.length)]
    Gbeat = ran1[Math.floor(Math.random() * ran1.length)]
    Hbeat = ran2[Math.floor(Math.random() * ran2.length)]
    Ibeat = ran3[Math.floor(Math.random() * ran3.length)]
    Jbeat = ran1[Math.floor(Math.random() * ran1.length)]
    Kbeat = ran1[Math.floor(Math.random() * ran1.length)]
    Lbeat = ran3[Math.floor(Math.random() * ran3.length)]
    Mbeat = ran3[Math.floor(Math.random() * ran3.length)]
    Nbeat = ran1[Math.floor(Math.random() * ran1.length)]
    }



    var PlaybackSpeed = 390

function playA(){
   setTimeout(WaitA0,0)
  } 
gen()
  function WaitA0(){
    document.getElementsByTagName("bgsound")[0].src = NoBeat;
    setTimeout(Wait0,0)
      }

  function Wait0(){
    document.getElementsByTagName("bgsound")[0].src = Abeat;
    setTimeout(Wait1,PlaybackSpeed)
      }
    function Wait1(){
    document.getElementsByTagName("bgsound")[0].src = Bbeat;
    setTimeout(Wait2,PlaybackSpeed)
    }
    function Wait2(){
    document.getElementsByTagName("bgsound")[0].src = Cbeat;
    setTimeout(Wait3,PlaybackSpeed)
    }
    function Wait3(){
    document.getElementsByTagName("bgsound")[0].src = Dbeat;
    setTimeout(Wait4,PlaybackSpeed)
    }
    function Wait4(){
    document.getElementsByTagName("bgsound")[0].src = Ebeat;
    setTimeout(Wait5,PlaybackSpeed)
    }
    function Wait5(){
    document.getElementsByTagName("bgsound")[0].src = Fbeat;
    setTimeout(Wait6,PlaybackSpeed)
    }
    function Wait6(){
    document.getElementsByTagName("bgsound")[0].src = Gbeat;
    setTimeout(Wait7,PlaybackSpeed)
    } 
    function Wait7(){
    document.getElementsByTagName("bgsound")[0].src = Hbeat;
    setTimeout(Wait8,PlaybackSpeed)
    }  
    function Wait8(){
    document.getElementsByTagName("bgsound")[0].src = Ibeat;
    setTimeout(Wait9,PlaybackSpeed)
    }
    function Wait9(){
    document.getElementsByTagName("bgsound")[0].src = Jbeat;
    setTimeout(Wait10,PlaybackSpeed)
    }
    function Wait10(){
    document.getElementsByTagName("bgsound")[0].src = Kbeat;
    setTimeout(Wait11,PlaybackSpeed)
    }
    function Wait11(){
    document.getElementsByTagName("bgsound")[0].src = Lbeat;
    setTimeout(Wait12,PlaybackSpeed)
    }
    function Wait12(){
    document.getElementsByTagName("bgsound")[0].src = Mbeat;
    setTimeout(Wait13,PlaybackSpeed)
    }
    function Wait13(){
    document.getElementsByTagName("bgsound")[0].src = Nbeat;

    }


